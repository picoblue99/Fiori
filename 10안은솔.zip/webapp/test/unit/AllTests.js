sap.ui.define([
	"exam/exprogram_10/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
